from pathlib import Path

manifest = Path("android/app/src/main/AndroidManifest.xml")
if not manifest.exists():
    raise SystemExit("Android manifest not found. Run `flutter create . --platforms=android` first.")

content = manifest.read_text(encoding="utf-8")
permissions = [
    '    <uses-permission android:name="android.permission.CAMERA"/>',
    '    <uses-permission android:name="android.permission.RECORD_AUDIO"/>',
]
missing = [line for line in permissions if line not in content]
if missing:
    marker = "<manifest"
    start = content.find(marker)
    end = content.find(">", start)
    if start < 0 or end < 0:
        raise SystemExit("Could not locate the manifest opening tag.")
    content = content[:end + 1] + "\n" + "\n".join(missing) + content[end + 1:]
    manifest.write_text(content, encoding="utf-8")
    print("Camera and microphone permissions added.")
else:
    print("Required permissions already exist.")
