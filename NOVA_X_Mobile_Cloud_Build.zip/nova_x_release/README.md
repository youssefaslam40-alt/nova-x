# NOVA X

Flutter starter project for the NOVA X mobile companion concept.

See [README_AR.md](README_AR.md) for current feature status and phone-only cloud APK build instructions.

This is a development starter, not a finished commercial application. AI, cloud services, and several advanced media features are not connected yet.
