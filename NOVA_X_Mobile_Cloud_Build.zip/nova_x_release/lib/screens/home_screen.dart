import 'package:flutter/material.dart';
import 'camera_screen.dart';
import 'gaming_screen.dart';
import 'device_screen.dart';
import 'ai_screen.dart';
import 'sound_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final _pages = const [
    _Dashboard(),
    CameraScreen(),
    GamingScreen(),
    SoundScreen(),
    DeviceScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pages[_index]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0D1423),
        indicatorColor: const Color(0xFF29356B),
        selectedIndex: _index,
        onDestinationSelected: (v) => setState(() => _index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.camera_alt_outlined), label: 'الكاميرا'),
          NavigationDestination(icon: Icon(Icons.sports_esports_outlined), label: 'الألعاب'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), label: 'الصوت'),
          NavigationDestination(icon: Icon(Icons.memory), label: 'الجهاز'),
        ],
      ),
    );
  }
}

class _Dashboard extends StatelessWidget {
  const _Dashboard();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        Row(
          children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: const LinearGradient(colors: [Color(0xFF4D6BFF), Color(0xFF9B5CFF)]),
              ),
              child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 29),
            ),
            const SizedBox(width: 12),
            const Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('NOVA X', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 2)),
                Text('YOUR PHONE. BEYOND LIMITS.', style: TextStyle(fontSize: 9, color: Color(0xFF9CAAC5), letterSpacing: 1.4)),
              ],
            )),
            const Icon(Icons.account_circle_outlined, size: 30, color: Color(0xFFB9C5E2)),
          ],
        ),
        const SizedBox(height: 26),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            gradient: const LinearGradient(
              begin: Alignment.topLeft, end: Alignment.bottomRight,
              colors: [Color(0xFF263A85), Color(0xFF34205D), Color(0xFF111A2B)],
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('WELCOME TO THE NEXT LEVEL', style: TextStyle(fontSize: 10, letterSpacing: 1.6, color: Color(0xFFD6DCFF))),
              SizedBox(height: 12),
              Text('كل أدواتك الذكية\\nفي مكان واحد.', style: TextStyle(fontSize: 27, height: 1.25, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text('كاميرا • ألعاب • صوت • ذكاء اصطناعي', style: TextStyle(color: Color(0xFFD0D7F5))),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const Text('استكشف NOVA X', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 13),
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.22,
          children: const [
            _FeatureCard(icon: Icons.camera_alt_rounded, title: 'NOVA CAMERA', subtitle: 'التصوير الاحترافي', color: Color(0xFF5C7CFF)),
            _FeatureCard(icon: Icons.sports_esports_rounded, title: 'NOVA GAMING', subtitle: 'مركز الألعاب', color: Color(0xFFB36BFF)),
            _FeatureCard(icon: Icons.graphic_eq_rounded, title: 'NOVA SOUND', subtitle: 'أدوات الصوت', color: Color(0xFF36C9C1)),
            _FeatureCard(icon: Icons.memory_rounded, title: 'NOVA DEVICE', subtitle: 'فحص الجهاز', color: Color(0xFFFFB65C)),
          ],
        ),
        const SizedBox(height: 18),
        Card(child: Padding(
          padding: const EdgeInsets.all(17),
          child: Row(children: [
            const Icon(Icons.auto_awesome, color: Color(0xFF9B8CFF), size: 30),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('NOVA AI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              SizedBox(height: 4),
              Text('مركز المساعد الذكي متعدد النماذج', style: TextStyle(color: Color(0xFF9CAAC5), fontSize: 12)),
            ])),
            IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AiScreen())), icon: const Icon(Icons.arrow_forward_ios_rounded, size: 17)),
          ]),
        )),
        const SizedBox(height: 12),
        const Text('ملاحظة: بعض أدوات الأداء والتصوير تعتمد على دعم الهاتف وإصدار النظام.', style: TextStyle(color: Color(0xFF8290AB), fontSize: 11)),
      ],
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final Color color;
  const _FeatureCard({required this.icon, required this.title, required this.subtitle, required this.color});
  @override
  Widget build(BuildContext context) => Card(child: Padding(
    padding: const EdgeInsets.all(15),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: color, size: 29),
      const SizedBox(height: 12),
      Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      const SizedBox(height: 4),
      Text(subtitle, style: const TextStyle(color: Color(0xFF9CAAC5), fontSize: 11)),
    ]),
  ));
}
