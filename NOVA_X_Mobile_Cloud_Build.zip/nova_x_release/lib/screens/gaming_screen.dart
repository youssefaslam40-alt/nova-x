import 'package:flutter/material.dart';

class GamingScreen extends StatelessWidget {
  const GamingScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('NOVA GAMING', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
    const SizedBox(height: 6),
    const Text('مركز الألعاب وإحصائيات جلسات اللعب', style: TextStyle(color: Color(0xFF9CAAC5))),
    const SizedBox(height: 18),
    _tile(Icons.sports_esports, 'مكتبة الألعاب', 'نقطة انطلاق لتنظيم ألعابك المثبتة'),
    _tile(Icons.gamepad, 'وحدات التحكم', 'دعم أذرع التحكم المتوافقة مع النظام'),
    _tile(Icons.screen_record, 'تسجيل الشاشة', 'استخدم مسجل الشاشة المدمج في جهازك'),
    _tile(Icons.query_stats, 'تحليل الأداء', 'معلومات الأداء المتاحة فقط حسب الجهاز'),
    _tile(Icons.tune, 'ملفات اللعب', 'إعدادات وتفضيلات لكل لعبة'),
    const SizedBox(height: 12),
    const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('تنبيه: لا يستطيع تطبيق عادي فرض FPS أعلى أو تغيير تردد المعالج أو مراقبة أداء كل لعبة على iOS. سنستخدم واجهات النظام الرسمية فقط.', style: TextStyle(color: Color(0xFFFFD28A), height: 1.5)))),
  ]);
  static Widget _tile(IconData i, String t, String s) => Card(child: ListTile(leading: Icon(i, color: const Color(0xFFB18BFF)), title: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(s, style: const TextStyle(fontSize: 11))));
}
