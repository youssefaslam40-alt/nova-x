import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';

class DeviceScreen extends StatefulWidget {
  const DeviceScreen({super.key});
  @override
  State<DeviceScreen> createState() => _DeviceScreenState();
}

class _DeviceScreenState extends State<DeviceScreen> {
  final _battery = Battery();
  String _batteryText = 'جارٍ الفحص...';
  String _networkText = 'جارٍ الفحص...';
  String _deviceText = 'جارٍ الفحص...';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      final conn = await Connectivity().checkConnectivity();
      final info = DeviceInfoPlugin();
      final android = await info.androidInfo;
      if (!mounted) return;
      setState(() {
        _batteryText = '$level% • ${state.name}';
        _networkText = conn.map((e) => e.name).join(', ');
        _deviceText = '${android.manufacturer} ${android.model} • Android ${android.version.release}';
      });
    } catch (e) {
      if (mounted) setState(() { _batteryText = 'غير متاح على هذا النظام'; _deviceText = 'تعذر قراءة معلومات الجهاز'; });
    }
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('NOVA DEVICE', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
    const SizedBox(height: 6),
    const Text('معلومات وتشخيص أساسي للجهاز', style: TextStyle(color: Color(0xFF9CAAC5))),
    const SizedBox(height: 18),
    _info(Icons.battery_full, 'البطارية', _batteryText),
    _info(Icons.wifi, 'الاتصال', _networkText),
    _info(Icons.phone_android, 'الجهاز', _deviceText),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: () { setState(() { _batteryText = 'جارٍ الفحص...'; }); _load(); }, icon: const Icon(Icons.refresh), label: const Text('إعادة الفحص')),
    const SizedBox(height: 12),
    const Text('هذه معلومات تشخيصية أساسية وليست فحصًا لصحة البطارية أو مكونات الهاتف الداخلية.', style: TextStyle(fontSize: 11, color: Color(0xFF8290AB))),
  ]);
  static Widget _info(IconData i, String title, String value) => Card(child: ListTile(leading: Icon(i, color: const Color(0xFFFFB65C)), title: Text(title), subtitle: Text(value)));
}
