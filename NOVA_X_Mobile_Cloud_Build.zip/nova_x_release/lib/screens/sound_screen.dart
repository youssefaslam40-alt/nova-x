import 'package:flutter/material.dart';

class SoundScreen extends StatelessWidget {
  const SoundScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('NOVA SOUND', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
    const SizedBox(height: 6),
    const Text('مركز أدوات الصوت', style: TextStyle(color: Color(0xFF9CAAC5))),
    const SizedBox(height: 18),
    const Card(child: Padding(padding: EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(Icons.graphic_eq, color: Color(0xFF36C9C1), size: 34),
      SizedBox(height: 12),
      Text('معادل صوت احترافي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      SizedBox(height: 6),
      Text('واجهة إعدادات أولية. تطبيق مؤثرات صوت النظام على كل التطبيقات يتطلب دعمًا وصلاحيات لا توفرها جميع الأجهزة.', style: TextStyle(color: Color(0xFF9CAAC5), height: 1.5)),
    ]))),
    _item(Icons.mic, 'استوديو التسجيل', 'تجهيز مسجل صوت في المرحلة التالية'),
    _item(Icons.headphones, 'اختبار السماعات', 'اختبار قنوات الصوت ومستوى الإخراج'),
    _item(Icons.noise_aware, 'تحسين التسجيل', 'إزالة الضوضاء عند معالجة ملف صوتي'),
  ]);
  static Widget _item(IconData i, String t, String s) => Card(child: ListTile(leading: Icon(i, color: const Color(0xFF36C9C1)), title: Text(t), subtitle: Text(s)));
}
