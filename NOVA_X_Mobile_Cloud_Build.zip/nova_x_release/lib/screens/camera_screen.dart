import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  bool _loading = true;
  String? _error;
  List<CameraDescription> _cameras = [];

  @override
  void initState() { super.initState(); _initCamera(); }

  Future<void> _initCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras.isEmpty) throw Exception('لا توجد كاميرا متاحة');
      _controller = CameraController(_cameras.first, ResolutionPreset.high, enableAudio: true);
      await _controller!.initialize();
      if (mounted) setState(() { _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = e.toString(); });
    }
  }

  Future<void> _takePhoto() async {
    if (_controller == null || !_controller!.value.isInitialized) return;
    try {
      final photo = await _controller!.takePicture();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم التقاط الصورة: ${photo.name}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر التصوير: $e')));
    }
  }

  @override
  void dispose() { _controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(18),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('NOVA CAMERA', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
      const SizedBox(height: 6),
      const Text('كاميرا مباشرة — الإصدار الأول', style: TextStyle(color: Color(0xFF9CAAC5))),
      const SizedBox(height: 18),
      Expanded(child: ClipRRect(
        borderRadius: BorderRadius.circular(25),
        child: Container(color: const Color(0xFF111A2B), width: double.infinity,
          child: _loading ? const Center(child: CircularProgressIndicator())
          : _error != null ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('تعذر تشغيل الكاميرا\\n$_error', textAlign: TextAlign.center)))
          : CameraPreview(_controller!),
        ),
      )),
      const SizedBox(height: 15),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: _initCamera, icon: const Icon(Icons.refresh), label: const Text('إعادة التشغيل'))),
        const SizedBox(width: 12),
        Expanded(child: FilledButton.icon(onPressed: _controller?.value.isInitialized == true ? _takePhoto : null, icon: const Icon(Icons.camera_alt), label: const Text('التقاط صورة'))),
      ]),
      const SizedBox(height: 8),
      const Text('ملاحظة: الصور تُلتقط عبر واجهة الكاميرا. حفظها في معرض الصور وإعدادات Pro المتقدمة ضمن مراحل التطوير التالية.', style: TextStyle(fontSize: 10, color: Color(0xFF8290AB))),
    ]),
  );
}
