import 'package:flutter/material.dart';

class AiScreen extends StatefulWidget {
  const AiScreen({super.key});
  @override
  State<AiScreen> createState() => _AiScreenState();
}

class _AiScreenState extends State<AiScreen> {
  final _controller = TextEditingController();
  final List<String> _messages = ['مرحبًا! أنا NOVA AI. اربط مزود نموذج ذكاء اصطناعي من إعدادات الخادم لتفعيل المحادثة الفعلية.'];
  bool _sending = false;

  void _send() {
    final value = _controller.text.trim();
    if (value.isEmpty) return;
    setState(() { _messages.add('أنت: $value'); _messages.add('NOVA AI: واجهة المحادثة جاهزة، لكن لم يتم ربط مزود ذكاء اصطناعي بعد.'); _controller.clear(); });
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('NOVA AI')),
    body: Column(children: [
      Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: _messages.length, itemBuilder: (_, i) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(_messages[i]))))),
      SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        Expanded(child: TextField(controller: _controller, decoration: const InputDecoration(hintText: 'اكتب رسالتك...', border: OutlineInputBorder()))),
        const SizedBox(width: 8),
        IconButton.filled(onPressed: _sending ? null : _send, icon: const Icon(Icons.send)),
      ]))),
    ]),
  );
}
