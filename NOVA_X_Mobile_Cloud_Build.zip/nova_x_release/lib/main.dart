import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NovaXApp());
}

class NovaXApp extends StatelessWidget {
  const NovaXApp({super.key});

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF080D18);
    return MaterialApp(
      title: 'NOVA X',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C7CFF),
          brightness: Brightness.dark,
          surface: const Color(0xFF111A2B),
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        cardTheme: CardTheme(
          color: const Color(0xFF111A2B),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
            side: const BorderSide(color: Color(0x223F69FF)),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
